python step0.py out1.txt out2.txt
python step1.py out1.txt out3.txt
python step2.py out2.txt out4.txt
python step3.py out3.txt out4.txt out5.txt
