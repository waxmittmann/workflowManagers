rm *.txt
